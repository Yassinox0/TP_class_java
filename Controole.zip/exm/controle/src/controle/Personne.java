package controle;


	abstract class Personne implements Comparable<Personne> {
	    private String nom;
	    private String prenom;
	    private String dateNaissance;

	    public Personne(String nom, String prenom, String dateNaissance) {
	        this.nom = nom;
	        this.prenom = prenom;
	        this.dateNaissance = dateNaissance;
	    }

	   

		public abstract void description();

	    @Override
	    public String toString() {
	        return "Nom: " + nom + ", Prénom: " + prenom + ", Date de naissance: " + dateNaissance;
	    }

	    @Override
	    public int compareTo(Personne personne) {
	        return this.nom.compareTo(personne.nom);
	    }
	}

