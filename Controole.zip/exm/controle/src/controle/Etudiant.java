package controle;

class Etudiant extends Personne {
    private String cne;
    private double noteFinale;

    public Etudiant(String nom, String prenom, String dateNaissance, String cne, double noteFinale) {
        super(nom, prenom, dateNaissance);
        this.cne = cne;
        this.noteFinale = noteFinale;
    }

    @Override
    public void description() {
        System.out.println("Statut: Etudiant, CNE: " + cne + ", Note finale: " + noteFinale);
    }
}