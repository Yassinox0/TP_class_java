package controle;

public class Professeur extends Personne {
	private String coursEnseigne;

    public Professeur(String nom, String prenom, String dateNaissance, String coursEnseigne) {
        super(nom, prenom, dateNaissance);
        this.coursEnseigne = coursEnseigne;
    }

    @Override
    public void description() {
        System.out.println("Statut: Professeur, Cours enseigné: " + coursEnseigne);
    }
}

	
	
		// TODO Auto-generated method stub

	


