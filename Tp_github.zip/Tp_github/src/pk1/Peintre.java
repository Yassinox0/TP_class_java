package pk1;

import java.util.Objects;

public class Peintre extends Artiste {
	 private String style;

	public Peintre(String nom, String prenom, String domaine, int age, String style) {
		super(nom, prenom, domaine, age);
		this.style = style;
	}

	@Override
	public String toString() {
		return "Peintre [style=" + style + ", toString()=" + super.toString() + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(style);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Peintre other = (Peintre) obj;
		return Objects.equals(style, other.style);
	}

}
