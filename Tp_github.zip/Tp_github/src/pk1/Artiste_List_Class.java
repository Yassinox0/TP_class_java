package pk1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class Artiste_List_Class {
	private List<Artiste> liste;

    // a. Fonction Java qui permet d’alimenter la liste
    public void alimenterListe(List<Artiste> newListe) {
        liste.addAll(newListe);
    }

    // b. Fonction Java qui permet d’afficher la liste (ligne par ligne)
    public void afficherListe() {
        for (Artiste artiste : liste) {
            System.out.println(artiste);
        }
    }

    // c. Fonction Java qui permet de parcourir (à l’aide d’un Iterateur) tous les éléments de la liste
    public void parcourirListe() {
        Iterator<Artiste> iterator = liste.iterator();
        while (iterator.hasNext()) {
            Artiste artiste = iterator.next();
            // Faites quelque chose avec l'artiste
        }
    }

    // d. Fonction Java qui permet d’insérer un élément dans la liste
    public void insererElement(Artiste artiste) {
        liste.add(artiste);
    }

    // e. Fonction Java qui permet de récupérer un élément
    public Artiste recupererElement(int index) {
        return liste.get(index);
    }

    // f. Fonction Java qui permet de supprimer un élément
    public void supprimerElement(Artiste artiste) {
        liste.remove(artiste);
    }

    // g. Fonction Java qui permet de trier la liste
    public void trierListe() {
        Collections.sort(liste);
    }

    // h. Fonction Java qui permet de copier la liste dans un nouveau tableau
    public List<Artiste> copierListeDansTableau() {
        return new ArrayList<>(liste);
    }

    // i. Fonction Java qui permet de mélanger les éléments de la liste
    public void melangerListe() {
        Collections.shuffle(liste);
    }

    // j. Fonction Java qui permet d’inverser les éléments de la liste
    public void inverserListe() {
        Collections.reverse(liste);
    }

    // k. Fonction Java qui permet d’extraire une partie de la liste
    public List<Artiste> extrairePartieListe(int debut, int fin) {
        return liste.subList(debut, fin);
    }

    // l. Fonction Java qui permet de comparer deux listes
    public boolean comparerDeuxListes(List<Artiste> autreListe) {
        return liste.equals(autreListe);
    }

    // m. Fonction Java d'échange de deux éléments dans une liste
    public void echangerDeuxElements(int index1, int index2) {
        Collections.swap(liste, index1, index2);
    }

    // n. Fonction Java qui permet de vider la liste
    public void viderListe() {
        liste.clear();
    }

    // o. Fonction Java qui permet de tester que la liste est vide ou non
    public boolean testerListeVide() {
        return liste.isEmpty();
    }
}
}
