package pk1;

import java.util.Arrays;
import java.util.Collections;

public class Artiste_Table_Class {
    private Artiste[] tableau;

    public Artiste_Table_Class(Artiste[] tableau) {
        this.tableau = tableau;
    }

    public void trierTableau() {
        Arrays.sort(tableau);
    }

    public void ajouterElement(Artiste artiste) {
        // Ajouter un nouvel element a la fin du tableau
        tableau = Arrays.copyOf(tableau, tableau.length + 1);
        tableau[tableau.length - 1] = artiste;
    }

    public void supprimerElement(Artiste artiste) {
        // Rechercher l'index de l'artiste à supprimer
        int index = -1;
        for (int i = 0; i < tableau.length; i++) {
            if (tableau[i].equals(artiste)) {
                index = i;
                break;
            }
        }

        // Si l'artiste est trouvé, créer un nouveau tableau sans cet artiste
        if (index != -1) {
            Artiste[] nouveauTableau = new Artiste[tableau.length - 1];
            System.arraycopy(tableau, 0, nouveauTableau, 0, index);
            System.arraycopy(tableau, index + 1, nouveauTableau, index, tableau.length - index - 1);
            tableau = nouveauTableau;
        }
    }

    public int compterElements() {
        return tableau.length;
    }

    public void inverserOrdreTableau() {
        //inverse l'ordre du tableau
        Collections.reverse(Arrays.asList(tableau));
    }

    public void afficherTableau() {
        for (Artiste artiste : tableau) {
            System.out.println(artiste);
        }
    }

    public Artiste getElementPlusGrand() {
        // Mme c'est pour trouve et renvoye l'artiste le plus agee
        if (tableau.length == 0) {
            return null;
        }

        Artiste plusAge = tableau[0];
        for (Artiste artiste : tableau) {
            if (artiste.getAge() > plusAge.getAge()) {
                plusAge = artiste;
            }
        }

        return plusAge;
    }

    public boolean testerEgaliteTableaux(Artiste[] autreTableau) {
        // pour tester l'egalite des tableaux
    	
        return Arrays.equals(tableau, autreTableau);
    }
}
